<?php

class Address
{
    public $blockNumber;
    public $streetName;
    public $floor;
    public $unitNumber;
    public $country;
    public $postalCode;
} 